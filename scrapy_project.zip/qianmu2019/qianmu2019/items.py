# -*- coding: utf-8 -*-

# Define here the models for your scraped items
#
# See documentation in:
# https://docs.scrapy.org/en/latest/topics/items.html

import scrapy


class Qianmu2019Item(scrapy.Item):
    name = scrapy.Field()
    rank = scrapy.Field()
    country = scrapy.Field()
    state = scrapy.Field()
    city = scrapy.Field()
    undergraduate_num = scrapy.Field()
    postgraduate_num = scrapy.Field()
    website = scrapy.Field()


class MovieItem(scrapy.Item):
    m_name = scrapy.Field()
    link = scrapy.Field()
    cover = scrapy.Field()
    detail_image = scrapy.Field()
    description = scrapy.Field()
    cover_name = scrapy.Field()
    film_time = scrapy.Field()
