# -*- coding: utf-8 -*-

# Define your item pipelines here
#
# Don't forget to add your pipeline to the ITEM_PIPELINES setting
# See: https://docs.scrapy.org/en/latest/topics/item-pipeline.html
import re

import pymysql
import redis
from scrapy import Request

from scrapy.exceptions import DropItem
from scrapy.pipelines.images import ImagesPipeline


class RedisPipeline(object):
    def open_spider(self, spider):
        self.r = redis.Redis(host='127.0.0.1')

    # def close_spider(self, spider):
    #     self.r.close()

    def process_item(self, item, spider):
        if self.r.sadd(spider.name, item['name']):
            return item
        raise DropItem


class MysqlPipeline(object):
    _host = "127.0.0.1"
    _port = 3306
    _db = "db"
    _user = "root"
    _password = "wjl1314"
    _charset = "utf8"

    def __init__(self, ):
        self.conn = pymysql.connect(
            host=self._host,
            port=self._port,
            db=self._db,
            user=self._user,
            password=self._password,
            charset=self._charset,
        )
        self.cur = self.conn.cursor()

    def close_spider(self, spider):
        self.cur.close()
        self.conn.close()

    def process_item(self, item, spider):
        # keys = item.keys()
        # values = [item[k] for k in keys]
        pass
        # keys, values = zip(*item.items())
        # sql = "insert into `{}` ({}) values ({})".format(
        #     'universities',
        #     ','.join(keys),
        #     ','.join(['%s'] * len(values))
        # )
        # self.cur.execute(sql, values)
        # self.conn.commit()
        # print(self.cur._last_executed)
        # return item


class MoviePipeline(MysqlPipeline):
    _db = "flask_2019"
    table_name = "movies"

    # def process_item(self, item, spider):
    #     keys, values = zip(*item.items())
    #     sql = "insert into `{}` ({}) values ({})".format(
    #         'movies',
    #         ','.join(keys),
    #         ','.join(['%s'] * len(values))
    #     )
    #     self.cur.execute(sql, values)
    #     print(sql)
    #     self.conn.commit()
    #     print(self.cur._last_executed)
    #     return item

    def process_item(self, item, spider):
        keys, values = zip(*item.items())
        sql = "INSERT INTO `{}` ({}) VALUES ({}) ON DUPLICATE KEY UPDATE {}".format(
            self.table_name,
            ','.join(keys),
            ','.join(['%s'] * len(values)),
            ','.join(['`{}`=%s'.format(k) for k in keys])
        )
        self.cur.execute(sql, values * 2)
        self.conn.commit()
        # print(self.cur._last_executed)
        return item


class SaveImagePipeline(ImagesPipeline):

    def get_media_requests(self, item, info):
        # 下载图片，如果传过来的是集合需要循环下载
        # meta里面的数据是从spider获取，然后通过meta传递给下面方法：file_path
        yield Request(url=item['cover'])

    def item_completed(self, results, item, info):
        # 是一个元组，第一个元素是布尔值表示是否成功
        if not results[0][0]:
            raise DropItem('下载失败')
        return item

    # 重命名，若不重写这函数，图片名为哈希，就是一串乱七八糟的名字
    def file_path(self, request, response=None, info=None):

        # 提取url前面名称作为图片名
        image_name = request.url.split('/')[-1]

        filename = u'{0}'.format(image_name)
        return filename
