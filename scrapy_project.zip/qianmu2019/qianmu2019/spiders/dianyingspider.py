# -*- coding: utf-8 -*-
import re
import uuid

import scrapy

from ..items import MovieItem


class DianyingspiderSpider(scrapy.Spider):
    name = 'dianyingspider'
    allowed_domains = ['dytt8.net', 'ygdy8.net']
    start_urls = ['https://www.ygdy8.net/html/gndy/china/list_4_%d.html' % i for i in range(20)]

    def parse(self, response):
        links = response.xpath('//div[@class="co_content8"]//td[2]//a[2]/@href').extract()
        for i in links:
            yield response.follow(i, self.parse_link)

    # def parse_link(self, response):
    #     response = response.replace(body=response.text.replace('\u3000', ''))
    #     item = MovieItem()
    #     item['m_name'] = response.xpath('//div[@class="title_all"]/h1//text()').extract_first()
    #     item['link'] = response.xpath('//div[@class="co_content8"]//a[contains(@href,"magnet:")]/@href').extract_first()
    #     item['cover'] = response.xpath('//div[@id="Zoom"]//img[1]/@src').extract_first()
    #     item['detail_image'] = response.xpath('//div[@id="Zoom"]//img[2]/@src').extract_first()
    #     item['desc'] = response.xpath('//div[@class="co_content8"]//p/text()').extract()
    #     yield item

    def parse_link(self, response):
        response = response.replace(body=response.text.replace('\u3000', ''))
        item = MovieItem()
        item['m_name'] = response.xpath('//div[@class="title_all"]/h1//text()').extract_first()
        item['link'] = response.xpath('//div[@class="co_content8"]//a[contains(@href,"magnet:")]/@href').extract_first()
        item['cover'] = response.xpath('//div[@id="Zoom"]//img[1]/@src').extract_first()
        item['cover_name'] = item['cover'].split("/")[-1]
        item['detail_image'] = response.xpath('//div[@id="Zoom"]//img[2]/@src').extract_first()
        d_list = response.xpath('//div[@class="co_content8"]//p/text()').extract()
        description = ["".join(d_list)]
        item['description'] = description
        film_time = response.xpath('//div[@class="co_content8"]//ul/text()').extract_first()
        item['film_time'] = re.findall('[0-9-]+', film_time)
        yield item
